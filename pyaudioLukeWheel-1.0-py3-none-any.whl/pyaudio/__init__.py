from pyaudio import *

def hello():
    print("hello")
