from pyaudio import *

def __version__():
    pass

def hello():
    print("hello")
