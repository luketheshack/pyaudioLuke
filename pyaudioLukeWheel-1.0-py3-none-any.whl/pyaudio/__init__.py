from pyaudio import *

__version__ = "0.2.8.1"

def __version__():
    return("0.2.8.1")

def hello():
    print("hello")
