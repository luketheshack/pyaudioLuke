def hello():
    print("hello")
