def runItOnce():
    import pyaudio

def hello():
    print("hello")
