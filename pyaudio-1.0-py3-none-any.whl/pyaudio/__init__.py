def runItOnce():
    from pyaudio import *

def hello():
    print("hello")
